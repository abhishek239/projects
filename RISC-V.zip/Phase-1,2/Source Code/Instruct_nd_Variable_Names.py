Instruct_names = {}

def add_to_instructnames(label,address):
    global Instruct_names
    Instruct_names[label] = int(address,16)






