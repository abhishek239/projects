PC = 0x0

def increment_PC():
    global PC
    PC += 4